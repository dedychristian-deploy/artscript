﻿namespace MSEDirectSendData
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtMSEIP = new TextBox();
            txtPlaylistUUID = new TextBox();
            lblPlaylist = new Label();
            txtTemplateID = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            btnTake = new Button();
            label4 = new Label();
            txtElementID = new TextBox();
            btnGet = new Button();
            richTextBox1 = new RichTextBox();
            btnActivatePlaylist = new Button();
            txtProfile = new TextBox();
            label5 = new Label();
            label6 = new Label();
            txtFieldID = new TextBox();
            label7 = new Label();
            btnTakeOut = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 27);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 0;
            label1.Text = "MSE IP";
            // 
            // txtMSEIP
            // 
            txtMSEIP.Location = new Point(112, 24);
            txtMSEIP.Name = "txtMSEIP";
            txtMSEIP.Size = new Size(100, 23);
            txtMSEIP.TabIndex = 1;
            txtMSEIP.Text = "localhost";
            // 
            // txtPlaylistUUID
            // 
            txtPlaylistUUID.Location = new Point(112, 60);
            txtPlaylistUUID.Name = "txtPlaylistUUID";
            txtPlaylistUUID.Size = new Size(475, 23);
            txtPlaylistUUID.TabIndex = 3;
            txtPlaylistUUID.Text = "F06280C3-27B8-4435-9A72-E51157E4CF33";
            // 
            // lblPlaylist
            // 
            lblPlaylist.AutoSize = true;
            lblPlaylist.Location = new Point(19, 63);
            lblPlaylist.Name = "lblPlaylist";
            lblPlaylist.Size = new Size(74, 15);
            lblPlaylist.TabIndex = 2;
            lblPlaylist.Text = "Playlist UUID";
            // 
            // txtTemplateID
            // 
            txtTemplateID.Location = new Point(112, 93);
            txtTemplateID.Name = "txtTemplateID";
            txtTemplateID.Size = new Size(100, 23);
            txtTemplateID.TabIndex = 5;
            txtTemplateID.Text = "10041";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 96);
            label2.Name = "label2";
            label2.Size = new Size(69, 15);
            label2.TabIndex = 4;
            label2.Text = "Template ID";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(19, 202);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(569, 102);
            textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(112, 139);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(475, 23);
            textBox2.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 147);
            label3.Name = "label3";
            label3.Size = new Size(61, 15);
            label3.TabIndex = 8;
            label3.Text = "Webstring";
            // 
            // btnTake
            // 
            btnTake.BackColor = Color.DarkRed;
            btnTake.ForeColor = SystemColors.ButtonFace;
            btnTake.Location = new Point(649, 204);
            btnTake.Name = "btnTake";
            btnTake.Size = new Size(75, 23);
            btnTake.TabIndex = 10;
            btnTake.Text = "TAKE";
            btnTake.UseVisualStyleBackColor = false;
            btnTake.Click += btnTake_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(249, 97);
            label4.Name = "label4";
            label4.Size = new Size(64, 15);
            label4.TabIndex = 11;
            label4.Text = "Element ID";
            // 
            // txtElementID
            // 
            txtElementID.Location = new Point(325, 93);
            txtElementID.Name = "txtElementID";
            txtElementID.Size = new Size(100, 23);
            txtElementID.TabIndex = 12;
            txtElementID.Text = "33";
            // 
            // btnGet
            // 
            btnGet.Location = new Point(649, 312);
            btnGet.Name = "btnGet";
            btnGet.Size = new Size(75, 23);
            btnGet.TabIndex = 13;
            btnGet.Text = "Get";
            btnGet.UseVisualStyleBackColor = true;
            btnGet.Click += btnGet_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(19, 310);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(568, 128);
            richTextBox1.TabIndex = 14;
            richTextBox1.Text = "";
            // 
            // btnActivatePlaylist
            // 
            btnActivatePlaylist.Location = new Point(649, 63);
            btnActivatePlaylist.Name = "btnActivatePlaylist";
            btnActivatePlaylist.Size = new Size(75, 23);
            btnActivatePlaylist.TabIndex = 15;
            btnActivatePlaylist.Text = "Activate";
            btnActivatePlaylist.UseVisualStyleBackColor = true;
            btnActivatePlaylist.Click += btnActivatePlaylist_Click;
            // 
            // txtProfile
            // 
            txtProfile.Location = new Point(310, 24);
            txtProfile.Name = "txtProfile";
            txtProfile.Size = new Size(100, 23);
            txtProfile.TabIndex = 16;
            txtProfile.Text = "default";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(236, 27);
            label5.Name = "label5";
            label5.Size = new Size(67, 15);
            label5.TabIndex = 17;
            label5.Text = "MSE Profile";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(19, 184);
            label6.Name = "label6";
            label6.Size = new Size(81, 15);
            label6.TabIndex = 18;
            label6.Text = "String to Send";
            // 
            // txtFieldID
            // 
            txtFieldID.Location = new Point(476, 93);
            txtFieldID.Name = "txtFieldID";
            txtFieldID.Size = new Size(100, 23);
            txtFieldID.TabIndex = 20;
            txtFieldID.Text = "txtInfo";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(431, 97);
            label7.Name = "label7";
            label7.Size = new Size(46, 15);
            label7.TabIndex = 19;
            label7.Text = "Field ID";
            // 
            // btnTakeOut
            // 
            btnTakeOut.Location = new Point(649, 233);
            btnTakeOut.Name = "btnTakeOut";
            btnTakeOut.Size = new Size(75, 23);
            btnTakeOut.TabIndex = 21;
            btnTakeOut.Text = "TAKE OUT";
            btnTakeOut.UseVisualStyleBackColor = true;
            btnTakeOut.Click += btnTakeOut_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnTakeOut);
            Controls.Add(txtFieldID);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtProfile);
            Controls.Add(btnActivatePlaylist);
            Controls.Add(richTextBox1);
            Controls.Add(btnGet);
            Controls.Add(txtElementID);
            Controls.Add(label4);
            Controls.Add(btnTake);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(txtTemplateID);
            Controls.Add(label2);
            Controls.Add(txtPlaylistUUID);
            Controls.Add(lblPlaylist);
            Controls.Add(txtMSEIP);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtMSEIP;
        private TextBox txtPlaylistUUID;
        private Label lblPlaylist;
        private TextBox txtTemplateID;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label3;
        private Button btnTake;
        private Label label4;
        private TextBox txtElementID;
        private Button btnGet;
        private RichTextBox richTextBox1;
        private Button btnActivatePlaylist;
        private TextBox txtProfile;
        private Label label5;
        private Label label6;
        private TextBox txtFieldID;
        private Label label7;
        private Button btnTakeOut;
    }
}
