Building of customer plugins is simplified by using the follwing VisualStudio VC10 property sheets.
They contain the location of the VizPlugin SDK includes and libs as well as the recommended
settings for compiler and linker along with a postbuildstep to copy the plugin, icon and shader
fragments to the VizArtist directory. Using them the compiler and linker settings need not
be set and can be left to "inherit from parent".

available property sheets.
VizPlugins.Win32.Debug.VC100.props
VizPlugins.Win32.Release.VC100.props
VizPlugins.x64.Debug.VC100.props
VizPlugins.x64.Release.VC100.props

The property sheets need to be customized for the location of the VizPlugin SDK.
PLUGINSDK_INC ... path that points to the include files of the VizPlugin SDK
PLUGINSDK_LIB ... path that points to the libraries of the VizPlugin SDK
VIZARTISTROOT ... path that points to the installation directory
all paths need to be ending in a trailing backslash '\'

It is recommended to install the property sheets in a top level directory so that all plugin
projects can access them. like
C:.
+---property sheets here
|   +---plugin1
|   |   +----plugin1.vcxproj
|   +---plugin2
|   |   +----plugin2.vcxproj
|   +---plugin3
|   |   +----plugin3.vcxproj
|   +---plugin4
|   |   +----plugin4.vcxproj
|   +---plugin5
|   |   +----plugin5.vcxproj


After that use the "Property Manager" in VisualStudio and add the appropriate property
sheets to each project. 

